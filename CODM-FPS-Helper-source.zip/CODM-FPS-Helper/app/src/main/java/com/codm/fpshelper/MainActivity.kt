package com.codm.fpshelper

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(13, 17, 25)
    private val panel = Color.rgb(25, 32, 44)
    private val accent = Color.rgb(90, 210, 170)
    private val mainText = Color.rgb(245, 247, 250)
    private val subText = Color.rgb(190, 199, 211)
    private lateinit var statusText: TextView
    private var checkedCount = 0
    private val totalChecks = 6

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildScreen()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(28))
        }
        scroll.addView(page)

        page.addView(label("CODM FPS HELPER", 13, accent, true))
        page.addView(label("بازی روان‌تر؛ تنظیمات هوشمندتر", 25, mainText, true).apply {
            setPadding(0, dp(8), 0, dp(8))
        })
        page.addView(label(
            "راهنمای آفلاین برای تنظیم FPS، کم‌کردن افت فریم و بررسی لگ. این برنامه خودش تنظیمات بازی را تغییر نمی‌دهد.",
            15, subText, false
        ))
        page.addView(space(18))

        page.addView(cardTitle("۱) تنظیمات پیشنهادی داخل کالاف"))
        page.addView(infoCard(
            "گرافیک: Low یا گزینه‌ای که فریم پایدارتر می‌دهد",
            "اگر تصویر روان نیست، گرافیک را پایین بیاور و در هر بار فقط یک گزینه را تغییر بده."
        ))
        page.addView(infoCard(
            "Frame Rate: بالاترین گزینهٔ پایدار",
            "اگر گوشی داغ می‌شود یا فریم افت می‌کند، یک سطح پایین‌تر را امتحان کن. بالاترین عدد همیشه بهترین تجربه نیست."
        ))
        page.addView(infoCard(
            "افکت‌های اضافی",
            "اگر در نسخهٔ بازی قابل انتخاب‌اند، افکت‌های غیرضروری مثل سایه‌های بلادرنگ را خاموش کن."
        ))
        page.addView(space(18))

        page.addView(cardTitle("۲) چک‌لیست قبل از مسابقه"))
        statusText = label("۰ از $totalChecks مورد انجام شده", 14, accent, true)
        page.addView(statusText)
        val items = listOf(
            "بازی را از فروشگاه رسمی به‌روز کن",
            "برنامه‌های سنگین پس‌زمینه را ببند",
            "حالت ذخیرهٔ باتری را خاموش کن",
            "فضای خالی کافی در حافظه نگه دار",
            "هنگام بازی گوشی را خنک نگه دار",
            "برای پینگ پایدار، اتصال اینترنت را بررسی کن"
        )
        items.forEach { text ->
            val cb = CheckBox(this).apply {
                this.text = text
                textSize = 14f
                setTextColor(mainText)
                buttonTintList = android.content.res.ColorStateList.valueOf(accent)
                setPadding(dp(4), dp(6), dp(4), dp(6))
                setOnCheckedChangeListener { _, isChecked ->
                    checkedCount += if (isChecked) 1 else -1
                    statusText.text = "$checkedCount از $totalChecks مورد انجام شده"
                }
            }
            page.addView(cb)
        }

        page.addView(space(14))
        page.addView(cardTitle("۳) تشخیص نوع مشکل"))
        page.addView(actionButton("افت فریم یا لگ تصویری") {
            showDetails(
                "اگر تصویر تکه‌تکه می‌شود",
                "۱. گرافیک را پایین بیاور.\\n۲. نرخ فریم را روی گزینه‌ای بگذار که پایدار می‌ماند.\\n۳. گوشی را خنک کن و بعد دوباره تست بگیر.\\n۴. اگر مشکل ادامه داشت، بازی و سیستم‌عامل را به‌روز کن."
            )
        })
        page.addView(space(8))
        page.addView(actionButton("پینگ بالا یا نوسانی") {
            showDetails(
                "اگر پینگ بالاست",
                "۱. نزدیک مودم بمان یا آنتن موبایل را بررسی کن.\\n۲. دانلودها و آپلودهای پس‌زمینه را متوقف کن.\\n۳. یک اتصال دیگر را امتحان کن.\\n۴. اگر فقط یک سرور مشکل دارد، ممکن است مسئله از مسیر شبکه یا سرور باشد. این برنامه پینگ را مستقیماً کم نمی‌کند."
            )
        })
        page.addView(space(8))
        page.addView(actionButton("داغ‌شدن گوشی") {
            showDetails(
                "اگر گوشی داغ می‌شود",
                "روشنایی را کمتر کن، هنگام بازی شارژ نکن اگر گرما زیاد می‌شود، قاب ضخیم را موقتاً بردار و بین مسابقه‌ها به گوشی فرصت خنک‌شدن بده. از یخچال یا سرمای شدید استفاده نکن."
            )
        })

        page.addView(space(18))
        page.addView(label(
            "یادآوری: نتیجه به مدل گوشی، نسخهٔ بازی، دما و شبکه بستگی دارد. از ابزارهای ناشناسِ مدعی افزایش FPS یا تغییر فایل‌های بازی دوری کن.",
            12, subText, false
        ))
        setContentView(scroll)
    }

    private fun showDetails(title: String, body: String) {
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(body.replace("\\n", "\n"))
            .setPositiveButton("باشه", null)
            .create()
        dialog.show()
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.START
            setLineSpacing(dp(3).toFloat(), 1.0f)
        }

    private fun cardTitle(text: String): TextView =
        label(text, 18, mainText, true).apply {
            setPadding(0, dp(4), 0, dp(10))
        }

    private fun infoCard(title: String, body: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(panel, 16)
        }
        box.addView(label(title, 15, accent, true))
        box.addView(space(5))
        box.addView(label(body, 14, subText, false))
        val lp = LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(9)
        }
        box.layoutParams = lp
        return box
    }

    private fun actionButton(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(mainText)
            background = rounded(panel, 14)
            isAllCaps = false
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(-1, dp(52))
        }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun space(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
