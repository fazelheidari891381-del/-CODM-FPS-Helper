# CODM FPS Helper

یک اپلیکیشن سادهٔ اندروید برای راهنمای تنظیمات FPS، کاهش افت فریم، بررسی لگ شبکه و داغ‌شدن گوشی در Call of Duty: Mobile.

## امکانات نسخهٔ 1.0
- راهنمای تنظیم گرافیک و Frame Rate
- چک‌لیست قبل از مسابقه
- راهنمای جداگانه برای افت فریم، پینگ بالا و داغ‌شدن
- رابط فارسی و بدون نیاز به اینترنت

## نکتهٔ مهم
این اپ تنظیمات CODM یا سیستم را خودکار تغییر نمی‌دهد و تضمین کاهش پینگ/FPS نمی‌دهد؛ فقط راهنمایی ارائه می‌کند. از دستکاری فایل‌های بازی یا ابزارهای ناشناس استفاده نکن.

## ساخت APK با Android Studio
1. Android Studio را نصب کن.
2. از صفحهٔ شروع، **Open** را بزن و پوشهٔ `CODM-FPS-Helper` را انتخاب کن.
3. صبر کن Gradle Sync کامل شود. اگر خواست SDK 35 یا JDK 17 نصب شود، از SDK Manager نصبشان کن.
4. از منوی **Build > Build Bundle(s) / APK(s) > Build APK(s)** را انتخاب کن.
5. بعد از موفقیت، روی **locate** بزن. APK معمولاً در `app/build/outputs/apk/debug/app-debug.apk` قرار می‌گیرد.

## ساختار پروژه
- `app/src/main/java/com/codm/fpshelper/MainActivity.kt` — کد رابط و منطق برنامه
- `app/src/main/AndroidManifest.xml` — تنظیمات پایهٔ اپ
- `app/build.gradle` — تنظیمات ساخت اپ
- `build.gradle` و `settings.gradle` — تنظیمات پروژه

## پیش‌نیازها
- Android Studio جدید
- Android SDK 35
- JDK 17
